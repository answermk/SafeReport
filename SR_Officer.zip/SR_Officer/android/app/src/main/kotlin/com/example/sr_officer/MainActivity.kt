package com.example.sr_officer

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
